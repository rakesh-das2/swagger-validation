package com.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import io.restassured.response.Response;

public class TestDemo {

    @Test
    public void test(){
        Response response=  RequestSpecificationFactory.getInstance("https://petstore.swagger.io/v2/swagger.json")
                .baseUri("http://petstore.swagger.io/v2")
                .header("api_key", "foo")
                .when().get("/pet/5");  // Replace with your actual endpoint
        Assertions.assertEquals(response.statusCode(), 200);
    }
}
