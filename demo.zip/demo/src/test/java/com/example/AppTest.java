package com.example;

import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import com.atlassian.oai.validator.restassured.OpenApiValidationFilter;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

/**
 * Unit test for simple App.
 */
public class AppTest
{

    // URL to the Swagger/OpenAPI specification
    private static final String SWAGGER_JSON_URL = "http://petstore.swagger.io/v2/swagger.json";

    // Base URI of the API service
    private static final String BASE_URI = "https://petstore.swagger.io/v2";

    // Create an instance of the OpenApiValidationFilter with the Swagger JSON URL
    private static final OpenApiValidationFilter validationFilter = new OpenApiValidationFilter(SWAGGER_JSON_URL);

    @Test
    public void testGetPetById() {
        // Set the base URI for RestAssured within the test method
        RestAssured.baseURI = BASE_URI;

        given()
                //.filter(validationFilter)
                .header("api_key","foo")
                .when()
                .get("/pet/1")  // Replace with your actual endpoint
                .then()
                .assertThat()
                .statusCode(200)
                .body("name", equalTo("doggie")); // Example of response body validation
    }

    @Test
    public void testGetPetById1() {
        // Set the base URI for RestAssured
        RestAssured.baseURI = BASE_URI;

        // Perform the GET request
        given()
                .filter(new OpenApiValidationFilter("http://petstore.swagger.io/v2/swagger.json"))
                .accept("application/json")  // Set the 'accept' header
                //.header("api_key", "foo")
                .when()
                .get("/pet/1")  // Specify the endpoint
                .then()
                .statusCode(200)  // Validate the status code
                .body("name", equalTo("dog"));  // Validate a field in the response body
    }

    @Test
    public void testGetInvalidPet() {
        // Set the base URI for RestAssured within the test method
        RestAssured.baseURI = BASE_URI;

        given()
                //.filter(validationFilter)
                .header("api_key","foo")
                .when()
                .get("/pet/9999")  // An endpoint that should not exist
                .then()
                .assertThat()
                .statusCode(404);
    }
}

