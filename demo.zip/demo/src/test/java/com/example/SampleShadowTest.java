package com.example;

public class SampleShadowTest {

    public static void main(String[] args) {

    }
}
