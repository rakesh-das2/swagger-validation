package com.example;


import com.atlassian.oai.validator.restassured.OpenApiValidationFilter;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.specification.RequestSpecification;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

public class RequestSpecificationFactory {
    private static final Logger log = LogManager.getLogger(RequestSpecificationFactory.class);

    public RequestSpecificationFactory(){

    }
    public static RequestSpecification getInstance(String swaggerJsonUrl){
        RequestSpecBuilder builder = new RequestSpecBuilder();
        builder.addHeader("Content-Type", "application/json");
        builder.addFilter(new RequestLoggingFilter());    // Logs the request
        builder.addFilter(new ResponseLoggingFilter());
        builder.addFilter(new OpenApiValidationFilter(swaggerJsonUrl));
        return RestAssured.given(builder.build());
    }
}
