package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLDatabaseConnection {

    // Replace the below details with your MySQL configuration
    private static final String URL = "jdbc:mysql://sql12.freesqldatabase.com:3306/sql12732954";
    private static final String USER = "sql12732954";
    private static final String PASSWORD = "jgUTZvBH5M";

    public static void main(String[] args) {
        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            // Load the MySQL JDBC driver (optional in modern JDBC versions)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection to the database
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Successfully connected to the database!");

            // Create a Statement object to execute the query
            statement = connection.createStatement();

            // Define your SQL query (modify the query according to your table structure)
            String query = "SELECT * FROM Employee;";  // Change 'your_table' to your actual table name

            // Execute the query and obtain the result set
            resultSet = statement.executeQuery(query);

            // Process the ResultSet
            System.out.println("Query Results:");
            while (resultSet.next()) {
                // Replace 'column_name' with your actual column name from the table
                String columnData = resultSet.getString("FirstName");
                System.out.println("Column Data: " + columnData);
            }

        } catch (SQLException e) {
            System.out.println("Error while connecting to the database or executing the query.");
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found.");
            e.printStackTrace();
        } finally {
            // Close the ResultSet, Statement, and Connection objects to free up resources
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
